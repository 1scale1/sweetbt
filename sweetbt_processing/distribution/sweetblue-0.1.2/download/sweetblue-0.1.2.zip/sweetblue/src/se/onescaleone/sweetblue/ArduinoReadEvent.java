package se.onescaleone.sweetblue;

import java.util.EventObject;

public class ArduinoReadEvent extends EventObject {

	public ArduinoReadEvent(Object source) {
		super(source);
		// TODO Auto-generated constructor stub
	}

}
