package se.onescaleone.sweetblue;

import java.util.EventListener;

public interface SweetBlueListener extends EventListener {

	public void SweetBlueConnected(SweetBlueEvent evt);
}

